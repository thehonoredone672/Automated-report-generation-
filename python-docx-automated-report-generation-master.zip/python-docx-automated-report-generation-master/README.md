# python-docx-automated-report-generation
I created and completed these projects by myself in my internship from 2020/02 to 2020/07
